package viewpackage;

import java.util.Scanner;

import com.Book;

import controllerpackage.BookMethods;

public class Main {

	public static void main(String[] args) {
	
	BookMethods bm = new BookMethods();
	Scanner sc = new Scanner(System.in);
	
	while (true) {
		
		System.out.println("1. Create book");
		System.out.println("2. Get book");
		System.out.println("3. Update book");
		System.out.println("4. Delete book");
		System.out.println("5. Display all books");
		System.out.println("6. Exit");
		System.out.println("Enter your choice");
		
		int choice = sc.nextInt();
		sc.nextLine();
		switch(choice) {
		
		case 1:
			System.out.println("Enter book id : ");
			int id = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter book name : ");
			String bName = sc.nextLine();
			System.out.println("Enter author name : ");
			String author = sc.nextLine();
			Book b = new Book(id,bName,author);
			bm.addBook(b);
			break;
			
		case 2:
			System.out.println("Enter bookname to search and get : ");
			String bookname = sc.nextLine();
			if(bm.searchBook(bookname)!=null) {
				bm.getBook(bookname);
			}
			else {
				System.out.println("No book found with name : "+bookname);
			}
			break;
			
		case 3:
			System.out.println("Enter original book name to search and update : ");
			String bookToSearch = sc.nextLine();
			sc.nextLine();
			System.out.println("Enter book id to update : ");
			int newId = sc.nextInt();
			System.out.println("Enter book name to update : ");
			String newBookName = sc.nextLine();
			sc.nextLine();
			System.out.println("Enter book author to update : ");
			String newAuthor = sc.nextLine();
			Book bnew = new Book(newId , newBookName , newAuthor);
			if(bm.searchBook(bookToSearch)!=null) {
				bm.updateBook(bookToSearch, bnew);
			}
			else {
				System.out.println("Book not found so update is not possible");
			}
			break;
			
		case 4:
			System.out.println("Enter bookname to search and get : ");
			String bookNameToDelete = sc.nextLine();
			if(bm.searchBook(bookNameToDelete)!=null) {
				bm.deleteBook(bookNameToDelete);
			}
			else {
				System.out.println("No book found with name : "+bookNameToDelete +" so cant delete");
			}
			break;
			
		case 5:
			bm.displayBooks();
			break;
			
			
		case 6:
			System.exit(0);
			sc.close();
			break;
			
		default:
            System.out.println("Invalid choice. Try again.");
		}
		
	}
	
	}
}
