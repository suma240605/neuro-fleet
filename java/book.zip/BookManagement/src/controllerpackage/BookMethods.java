package controllerpackage;

import java.util.ArrayList;

import com.Book;

public class BookMethods {

	ArrayList<Book> al = new ArrayList<>();
	
	
	public void createBook(int bookId , String bookName , String author) {
		int id = al.size()+1;
		Book b1 = new Book(id,bookName,author);
		System.out.println("Created book succesfully : "+b1);
	}
	 
	
	public Book searchBook(String bookName) {
		for(Book b : al) {
			if(b.getBookName().equalsIgnoreCase(bookName)) {
				return b;
			}
		}
		return null;
	}
	
	public void getBook(String bookName) {
		for(Book b : al) {
			if(b.getBookName().equalsIgnoreCase(bookName)) {
				System.out.println("Successfully got the book : "+b);
			}
		}
	}
	
	
	public void addBook(Book b) {
		al.add(b);
		System.out.println("Added book successfully : "+b);
	}
	
	
	public void updateBook(String bookName , Book b) {
		for(int i=0;i<al.size();i++) {
			if(al.get(i).getBookName().equalsIgnoreCase(bookName)) {
				al.set(i, b);
			}
		}
		System.out.println("Updated succesfully book : "+b);
	}
	
	
	public void deleteBook(String bookName) {
		for(int i=0;i<al.size();i++) {
			if(al.get(i).getBookName().equalsIgnoreCase(bookName)) {
				al.remove(i);
			}
		}
		System.out.println("Deleted successfully book : "+bookName);
	}
	
	
	public void displayBooks() {
	    if (al.isEmpty()) {
	        System.out.println("No books available.");
	        return;
	    }
	    for (Book b : al) {
	        System.out.println(b);
	    }
	}

}
