package com;

import java.util.ArrayList;

public class Playlist implements Playable{

	int playlistId;
	String playlistName;
	ArrayList<Song> pl = new ArrayList<>();
	
	
	public Playlist(int playlistId, String playlistName) {
		this.playlistId = playlistId;
		this.playlistName = playlistName;
		this.pl = new ArrayList<>();
	}

	void addSong(Song s) {
		pl.add(s);
		System.out.println("Added song : "+s);
	}
	
	void removeSongById(int playlistId) {
		for(int i=0;i<pl.size();i++) {
			if(pl.get(i).getSongId()==playlistId) {
				pl.remove(i);
			}
		}
		System.out.println("Removed song by id : "+playlistId);
	}
	
	void displaySongs() {
		System.out.println(pl);
	}
	
	public void play(String title) {
		System.out.println("playing song with title : "+title);
	}
	
	public void play(int songId) {
		System.out.println("playing song with id : "+songId);
	}
	
	public void pause(String title) {
		System.out.println("pausing song with title : "+title);
	}
	
	public void pause(int songId) {
		System.out.println("pausing song with id : "+songId);
	}
	
	public void stop(String title) {
		System.out.println("stopped song with title : "+title);
	}
	
	public void stop(int songId) {
		System.out.println("stopped song with id : "+songId);
	}

	@Override
	public String toString() {
		return "Playlist [playlistId=" + playlistId + ", playlistName=" + playlistName + ", pl=" + pl + "]";
	}
	
	
}
