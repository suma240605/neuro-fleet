package com;

import java.util.ArrayList;

public class MusicPlayer {

	ArrayList<Song> allSongs = new ArrayList<>();
	
	ArrayList<Playlist> playlists = new ArrayList<>();
	
	void addSong(Song s) {
		allSongs.add(s);
		System.out.println("Added song : "+s);
	}
	
	void updateSong(String songname, Song s) {
		for(int i=0;i<allSongs.size();i++) {
			if(allSongs.get(i).getTitle().equals(songname)) {
				allSongs.set(i,s);
			}
		}
		System.out.println("Updated song : "+s);
	}
	
	void deleteSong(String songname) {
		for(int i=0;i<allSongs.size();i++) {
			if(allSongs.get(i).getTitle().equals(songname)) {
				allSongs.remove(i);
			}
		}
		System.out.println("Deleted song : "+songname);
	}
	
	void displayAllSongs() {
		System.out.println(allSongs);
	}
	
	void createPlaylist(String playListName) {
		int id = playlists.size()+1;
		Playlist p = new Playlist(id,playListName);
		playlists.add(p);
		System.out.println("Created playlist : "+p);
	}
	
	void addSongToPlaylist(String playListName, Song s) {
		for(Playlist p : playlists) {
			if(p.playlistName.equals(playListName)) {
				p.addSong(s);
				System.out.println("Added song to playlist : "+playListName);
			}
		}
		System.out.println("Playlist not found "+s);
	}
	
	void deletePlaylist(String playListName) {
		for(int i=0;i<playlists.size();i++) {
			if(playlists.get(i).playlistName.equals(playListName)) {
				playlists.remove(i);
				System.out.println("Deleted playlist : "+playListName);
			}
		}
	}
	
	void playPlayList(String playListName) {
		for(Playlist p :playlists) {
			if(p.playlistName.equals(playListName)) {
				System.out.println("Playing playlist...... : ");
				p.displaySongs();
			}
		}
		System.out.println("Playlist not found");
	}
	
	Playlist getPlayList(String playListName) {
		for(Playlist p :playlists) {
			if(p.playlistName.equals(playListName)) {
				return p;
			}
		}
		return null;
	}
	
	void displayAllPlaylists() {
		if(playlists.isEmpty()) {
			System.out.println("Playlist is empty");
		}
		else {
		for(Playlist p : playlists) {
			System.out.println(p);
		}
	}
	}
	
}
