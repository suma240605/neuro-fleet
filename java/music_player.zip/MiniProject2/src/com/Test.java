package com;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Song s1 = new Song(1, "Samajavaragamana", "Sid Sriram", 230);
		Song s2 = new Song(2, "Butta Bomma", "Armaan Malik", 210);
		Song s3 = new Song(3, "Naatu Naatu", "Rahul Sipligunj & Kaala Bhairava", 240);
		Song s4 = new Song(4, "Oo Antava", "Indravathi Chauhan", 190);
		Song s5 = new Song(5, "Ramulo Ramula", "Anurag Kulkarni & Mangli", 220);

		MusicPlayer player = new MusicPlayer();

		player.addSong(s1);
		player.addSong(s2);
		player.addSong(s3);
		player.addSong(s4);
		player.addSong(s5);

		while (true) {
            System.out.println("\n----- Music Player Menu -----");
            System.out.println("1. Add New Song");
            System.out.println("2. Update Existing Song");
            System.out.println("3. Delete Song");
            System.out.println("4. Display All Songs");
            System.out.println("5. Create New Playlist");
            System.out.println("6. Add Song to Playlist");
            System.out.println("7. Display All Playlists");
            System.out.println("8. Display Songs in Playlist");
            System.out.println("9. Play Song in Playlist");
            System.out.println("10. Pause Song in Playlist");
            System.out.println("11. Stop Song in Playlist");
            System.out.println("12. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine();
            
            switch(choice) {
            
            case 1:
            	System.out.print("Enter Song ID: ");
                int id = sc.nextInt();
                sc.nextLine();
                System.out.print("Enter Title: ");
                String title = sc.nextLine();
                System.out.print("Enter Artist: ");
                String artist = sc.nextLine();
                System.out.print("Enter Duration (in sec): ");
                long duration = sc.nextLong();
                sc.nextLine();

                Song newSong = new Song(id, title, artist, duration);
                player.addSong(newSong);
                break;
                
            case 2:
            	System.out.print("Enter the title of the song to update: ");
                String oldTitle = sc.nextLine();
                System.out.print("Enter new Song ID: ");
                int newId = sc.nextInt();
                sc.nextLine();
                System.out.print("Enter new Title: ");
                String newTitle = sc.nextLine();
                System.out.print("Enter new Artist: ");
                String newArtist = sc.nextLine();
                System.out.print("Enter new Duration (in sec): ");
                long newDuration = sc.nextLong();
                sc.nextLine();

                Song updatedSong = new Song(newId, newTitle, newArtist, newDuration);
                player.updateSong(oldTitle, updatedSong);
                break;
                
            case 3:
            	System.out.println("Enter song name to delete: ");
            	String songToDelete = sc.nextLine();
            	player.deleteSong(songToDelete);
            	break;
            	
            case 4:
            	player.displayAllSongs();
            	break;
            	
            case 5:
            	System.out.println("Enter playlist name to create: ");
            	String playListName = sc.nextLine();
            	player.createPlaylist(playListName);
            	break;
            	
            case 6:
            	System.out.print("Enter the title of the playlist to add: ");
                String plName = sc.nextLine();
                System.out.print("Enter Song title to add in playlist: ");
                int titleToAdd = sc.nextInt();
                sc.nextLine();
                
                Song flag = null;
                for(Song s : player.allSongs) {
                	if(s.getTitle().equals(titleToAdd)) {
                		flag = s;
                	}
                }
                if(flag!=null) {
                	player.addSongToPlaylist(plName, flag);
                }
                else {
                	System.out.println("Playlist not found");
                }
                break;
                
            case 7:
            	player.displayAllPlaylists();
            	break;
            	
            case 8:
            	System.out.println("Enter playlist name: ");
            	String plToSearch = sc.nextLine();
            	Playlist p = player.getPlayList(plToSearch);
            	if(p!=null) {
            		p.displaySongs();
            	}
            	else {
            		System.out.println("Playlist not found");
            	}
            	break;
            	
            case 9:
            	System.out.println("Enter playlist name: ");
            	String plname = sc.nextLine();
            	System.out.print("Enter Song Title to Play: ");
                String playTitle = sc.nextLine();
            	Playlist p1 = player.getPlayList(plname);
            	if(p1!=null) {
            		player.playPlayList(playTitle);
            	}
            	else {
            		System.out.println("Playlist not found");
            	}
            	break;
            	
            case 10:
            	System.out.print("Enter Playlist Name: ");
                String listToPause = sc.nextLine();
                System.out.print("Enter Song Title to Pause: ");
                String pauseTitle = sc.nextLine();
                Playlist pl2 = player.getPlayList(listToPause);
                if (pl2 != null) {
                	pl2.pause(pauseTitle);
                }
                else {
                	System.out.println("Playlist not found.");
                }
                break;
                
            case 11:
            	System.out.print("Enter Playlist Name: ");
                String listToStop = sc.nextLine();
                System.out.print("Enter Song Title to Pause: ");
                String stopTitle = sc.nextLine();
                Playlist pl3 = player.getPlayList(listToStop);
                if (pl3 != null) {
                	pl3.pause(stopTitle);
                }
                else {
                	System.out.println("Playlist not found.");
                }
                break;
                
            case 12:
            	System.out.println("Exiting Music Player!!!!!");
            	System.exit(0);
                sc.close();
                break;

            default:
                System.out.println("Invalid choice. Try again.");
            }
            	
		}
	}
	
}
