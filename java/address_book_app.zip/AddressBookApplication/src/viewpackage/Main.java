package viewpackage;

import java.util.Scanner;
import com.Contact;
import controllerpackage.ContactMethods;

public class Main {

	public static void main(String[] args) {

		ContactMethods cm = new ContactMethods();
		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("\n1. Add Contact");
			System.out.println("2. Update Contact");
			System.out.println("3. Delete Contact");
			System.out.println("4. Display All Contacts");
			System.out.println("5. Search Contact");
			System.out.println("6. Exit");
			System.out.print("Enter your choice: ");
			int choice = sc.nextInt();
			sc.nextLine(); 

			switch (choice) {

			case 1:
				System.out.print("Enter name: ");
				String name = sc.nextLine();
				System.out.print("Enter phone number: ");
				String phone = sc.nextLine();
				System.out.print("Enter email: ");
				String email = sc.nextLine();
				cm.addContact(new Contact(name, phone, email));
				break;

			case 2:
				System.out.print("Enter the name of the contact to update: ");
				String oldName = sc.nextLine();
				System.out.print("Enter new name: ");
				String newName = sc.nextLine();
				System.out.print("Enter new phone number: ");
				String newPhone = sc.nextLine();
				System.out.print("Enter new email: ");
				String newEmail = sc.nextLine();
				cm.updateContact(oldName, new Contact(newName, newPhone, newEmail));
				break;

			case 3:
				System.out.print("Enter name of contact to delete: ");
				String delName = sc.nextLine();
				cm.deleteContact(delName);
				break;

			case 4:
				cm.displayContacts();
				break;

			case 5:
				System.out.print("Enter name of contact to search: ");
				String searchName = sc.nextLine();
				Contact found = cm.searchContact(searchName);
				if (found != null) {
					System.out.println("Contact Found: " + found);
				} else {
					System.out.println("Contact not found.");
				}
				break;

			case 6:
				sc.close();
				System.exit(0);

			default:
				System.out.println("Invalid choice. Try again.");
			}
		}
	}
}
