package controllerpackage;

import java.util.ArrayList;
import com.Contact;
import com.ContactInterface;

public class ContactMethods implements ContactInterface {

	ArrayList<Contact> contactList = new ArrayList<>();

	@Override
	public void addContact(Contact contact) {
		contactList.add(contact);
		System.out.println("Contact added successfully: " + contact);
	}

	@Override
	public void updateContact(String name, Contact updatedContact) {
		for (int i = 0; i < contactList.size(); i++) {
			if (contactList.get(i).getName().equalsIgnoreCase(name)) {
				contactList.set(i, updatedContact);
				System.out.println("Contact updated successfully.....");
				return;
			}
		}
		System.out.println("Contact not found....");
	}

	@Override
	public void deleteContact(String name) {
		for (int i = 0; i < contactList.size(); i++) {
			if (contactList.get(i).getName().equalsIgnoreCase(name)) {
				contactList.remove(i);
				System.out.println("Contact deleted successfully....");
				return;
			}
		}
		System.out.println("Contact not found....");
	}

	@Override
	public void displayContacts() {
		if (contactList.isEmpty()) {
			System.out.println("No contacts to display.");
		} else {
			for (Contact c : contactList) {
				System.out.println(c);
			}
		}
	}

	@Override
	public Contact searchContact(String name) {
		for (Contact c : contactList) {
			if (c.getName().equalsIgnoreCase(name)) {
				return c;
			}
		}
		return null;
	}
}
