package com;

public interface ContactInterface {

	void addContact(Contact contact);
	
	void updateContact(String name, Contact updatedContact);
	
	void deleteContact(String name);
	
	void displayContacts();
	
	Contact searchContact(String name);
}
